from pydantic import BaseModel
from typing import List, Optional


class UserBase(BaseModel):
    username: str
    email: str


class UserCreate(UserBase):
    password: str
    is_admin: Optional[bool] = False


class User(UserBase):
    id: int

    class Config:
        orm_mode = True


class ProductBase(BaseModel):
    name: str
    type: str


class ProductCreate(ProductBase):
    owner_id: int


class ProductUpdate(BaseModel):
    name: Optional[str]
    type: Optional[str]
    owner_id: Optional[int]


class Product(ProductBase):
    id: int
    owner_id: int

    class Config:
        orm_mode = True


class ComponentBase(BaseModel):
    name: str
    price: float


class ComponentCreate(ComponentBase):
    product_id: int


class ComponentUpdate(BaseModel):
    name: Optional[str]
    price: Optional[float]
    product_id: Optional[int]


class Component(ComponentBase):
    id: int
    product_id: int

    class Config:
        orm_mode = True


class ComputerBase(BaseModel):
    name: str
    cpu: str
    gpu: str
    ram: str
    storage: str
    price: float


class ComputerCreate(ComputerBase):
    product_id: int


class ComputerUpdate(BaseModel):
    name: Optional[str]
    cpu: Optional[str]
    gpu: Optional[str]
    ram: Optional[str]
    storage: Optional[str]
    price: Optional[float]
    product_id: Optional[int]


class Computer(ComputerBase):
    id: int
    product_id: int

    class Config:
        orm_mode = True


class LaptopBase(BaseModel):
    name: str
    cpu: str
    gpu: str
    ram: str
    storage: str
    screen_size: str
    weight: float
    price: float


class LaptopCreate(LaptopBase):
    product_id: int


class LaptopUpdate(BaseModel):
    name: Optional[str]
    cpu: Optional[str]
    gpu: Optional[str]
    ram: Optional[str]
    storage: Optional[str]
    screen_size: Optional[str]
    weight: Optional[float]
    price: Optional[float]
    product_id: Optional[int]


class Laptop(LaptopBase):
    id: int
    product_id: int

    class Config:
        orm_mode = True


class CartItemBase(BaseModel):
    quantity: int


class CartItemCreate(CartItemBase):
    product_id: int


class CartItemUpdate(BaseModel):
    quantity: Optional[int]
    product_id: Optional[int]


class CartItem(CartItemBase):
    id: int
    product_id: int

    class Config:
        orm_mode = True
