from sqlalchemy.orm import Session

import models, schemas


"""
    USER
"""


def get_user(db: Session, username: str):
    return db.query(models.User).filter(models.User.username == username).first()


def get_user_by_email(db: Session, email: str):
    return db.query(models.User).filter(models.User.email == email).first()


def get_users(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.User).offset(skip).limit(limit).all()


def create_user(db: Session, user: schemas.UserCreate):
    db_user = models.User(
        username=user.username,
        email=user.email,
        password=user.password,
        is_admin=user.is_admin if user.is_admin is not None else False,  # Handle optional is_admin
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

"""
    PRODUCT
"""


def get_product(db: Session, product_id: int):
    return db.query(models.Product).filter(models.Product.id == product_id).first()


def get_products(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Product).offset(skip).limit(limit).all()


def create_product(db: Session, product: schemas.ProductCreate):
    db_product = models.Product(
        name=product.name, type=product.type, owner_id=product.owner_id
    )
    db.add(db_product)
    db.commit()
    db.refresh(db_product)
    return db_product


def update_product(db: Session, product_id: int, product: schemas.ProductUpdate):
    db_product = get_product(db, product_id)
    if db_product is None:
        return None

    for field, value in product.dict(exclude_unset=True).items():
        setattr(db_product, field, value)

    db.commit()
    db.refresh(db_product)
    return db_product


def delete_product(db: Session, product_id: int):
    db_product = get_product(db, product_id)
    if db_product is None:
        return None

    db.delete(db_product)
    db.commit()
    return db_product


"""
    COMPONENT
"""


def get_component(db: Session, component_id: int):
    return db.query(models.Component).filter(models.Component.id == component_id).first()


def get_components(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Component).offset(skip).limit(limit).all()


def create_component(db: Session, component: schemas.ComponentCreate):
    db_component = models.Component(
        name=component.name, product_id=component.product_id, price=component.price
    )
    db.add(db_component)
    db.commit()
    db.refresh(db_component)
    return db_component


def update_component(db: Session, component_id: int, component: schemas.ComponentUpdate):
    db_component = get_component(db, component_id)
    if db_component is None:
        return None

    for field, value in component.dict(exclude_unset=True).items():
        setattr(db_component, field, value)

    db.commit()
    db.refresh(db_component)
    return db_component


def delete_component(db: Session, component_id: int):
    db_component = get_component(db, component_id)
    if db_component is None:
        return None

    db.delete(db_component)
    db.commit()
    return db_component


"""
    COMPUTER
"""


def get_computer(db: Session, computer_id: int):
    return db.query(models.Computer).filter(models.Computer.id == computer_id).first()


def get_computers(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Computer).offset(skip).limit(limit).all()


def create_computer(db: Session, computer: schemas.ComputerCreate):
    db_computer = models.Computer(
        product_id=computer.product_id,
        name=computer.name,
        cpu=computer.cpu,
        gpu=computer.gpu,
        ram=computer.ram,
        storage=computer.storage,
        price=computer.price,
    )
    db.add(db_computer)
    db.commit()
    db.refresh(db_computer)
    return db_computer


def update_computer(db: Session, computer_id: int, computer: schemas.ComputerUpdate):
    db_computer = get_computer(db, computer_id)
    if db_computer is None:
        return None

    for field, value in computer.dict(exclude_unset=True).items():
        setattr(db_computer, field, value)

    db.commit()
    db.refresh(db_computer)
    return db_computer


def delete_computer(db: Session, computer_id: int):
    db_computer = get_computer(db, computer_id)
    if db_computer is None:
        return None

    db.delete(db_computer)
    db.commit()
    return db_computer


"""
    LAPTOP
"""


def get_laptop(db: Session, laptop_id: int):
    return db.query(models.Laptop).filter(models.Laptop.id == laptop_id).first()


def get_laptops(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Laptop).offset(skip).limit(limit).all()


def create_laptop(db: Session, laptop: schemas.LaptopCreate):
    db_laptop = models.Laptop(
        product_id=laptop.product_id,
        name=laptop.name,
        cpu=laptop.cpu,
        gpu=laptop.gpu,
        ram=laptop.ram,
        storage=laptop.storage,
        screen_size=laptop.screen_size,
        weight=laptop.weight,
        price=laptop.price,
    )
    db.add(db_laptop)
    db.commit()
    db.refresh(db_laptop)
    return db_laptop


def update_laptop(db: Session, laptop_id: int, laptop: schemas.LaptopUpdate):
    db_laptop = get_laptop(db, laptop_id)
    if db_laptop is None:
        return None

    for field, value in laptop.dict(exclude_unset=True).items():
        setattr(db_laptop, field, value)

    db.commit()
    db.refresh(db_laptop)
    return db_laptop


def delete_laptop(db: Session, laptop_id: int):
    db_laptop = get_laptop(db, laptop_id)
    if db_laptop is None:
        return None

    db.delete(db_laptop)
    db.commit()
    return db_laptop


"""
    CART ITEM
"""


def get_cart_item(db: Session, cart_item_id: int):
    return db.query(models.CartItem).filter(models.CartItem.id == cart_item_id).first()


def get_cart_items(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.CartItem).offset(skip).limit(limit).all()


def create_cart_item(db: Session, cart_item: schemas.CartItemCreate):
    db_cart_item = models.CartItem(product_id=cart_item.product_id, quantity=cart_item.quantity)
    db.add(db_cart_item)
    db.commit()
    db.refresh(db_cart_item)
    return db_cart_item


def update_cart_item(db: Session, cart_item_id: int, cart_item: schemas.CartItemUpdate):
    db_cart_item = get_cart_item(db, cart_item_id)
    if db_cart_item is None:
        return None

    for field, value in cart_item.dict(exclude_unset=True).items():
        setattr(db_cart_item, field, value)

    db.commit()
    db.refresh(db_cart_item)
    return db_cart_item


def delete_cart_item(db: Session, cart_item_id: int):
    db_cart_item = get_cart_item(db, cart_item_id)
    if db_cart_item is None:
        return None

    db.delete(db_cart_item)
    db.commit()
    return db_cart_item