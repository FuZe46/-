from sqlalchemy import Boolean, Column, Float, ForeignKey, Integer, String, DateTime
from sqlalchemy.orm import relationship
from datetime import datetime

from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)
    is_admin = Column(Boolean, default=False)

    products = relationship("Product", back_populates="owner")

class Product(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    type = Column(String(255), nullable=False)
    owner_id = Column(Integer, ForeignKey("users.id"))

    owner = relationship(User, back_populates="products")
    components = relationship("Component", back_populates="product")
    computers = relationship("Computer", back_populates="product")
    laptops = relationship("Laptop", back_populates="product")

class Component(Base):
    __tablename__ = "components"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"))
    price = Column(Float, nullable=False)

    product = relationship(Product, back_populates="components")

class Computer(Base):
    __tablename__ = "computers"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"))
    name = Column(String(255), nullable=False)
    cpu = Column(String(255), nullable=False)
    gpu = Column(String(255), nullable=False)
    ram = Column(String(255), nullable=False)
    storage = Column(String(255), nullable=False)
    price = Column(Float, nullable=False)

    product = relationship(Product, back_populates="computers")

class Laptop(Base):
    __tablename__ = "laptops"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"))
    name = Column(String(255), nullable=False)
    cpu = Column(String(255), nullable=False)
    gpu = Column(String(255), nullable=False)
    ram = Column(String(255), nullable=False)
    storage = Column(String(255), nullable=False)
    screen_size = Column(String(255), nullable=False)
    weight = Column(Float, nullable=False)
    price = Column(Float, nullable=False)

    product = relationship(Product, back_populates="laptops")

class CartItem(Base):
    __tablename__ = "cart_items"

    id = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"))
    quantity = Column(Integer, nullable=False)

    product = relationship(Product)