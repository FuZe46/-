from typing import List
from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy.orm import Session

import uvicorn
import crud, models, schemas
from database import SessionLocal, engine

app = FastAPI()
# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# User Endpoints

@app.post("/users/", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    db_user = crud.get_user_by_email(db, email=user.email)
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    return crud.create_user(db=db, user=user)


@app.get("/users/{username}", response_model=schemas.User)
def read_user(username: str, db: Session = Depends(get_db)):
    db_user = crud.get_user(db, username=username)
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return db_user


@app.get("/users/", response_model=List[schemas.User])
def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    return crud.get_users(db, skip=skip, limit=limit)


# Product Endpoints

@app.get("/products/{product_id}", response_model=schemas.Product)
def read_product(product_id: int, db: Session = Depends(get_db)):
    db_product = crud.get_product(db, product_id=product_id)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product


@app.post("/products/", response_model=schemas.Product)
def create_product(product: schemas.ProductCreate, db: Session = Depends(get_db)):
    return crud.create_product(db=db, product=product)


@app.put("/products/{product_id}", response_model=schemas.Product)
def update_product(product_id: int, product: schemas.ProductUpdate, db: Session = Depends(get_db)):
    db_product = crud.update_product(db, product_id, product)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product


@app.delete("/products/{product_id}", response_model=schemas.Product)
def delete_product(product_id: int, db: Session = Depends(get_db)):
    db_product = crud.delete_product(db, product_id)
    if db_product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return db_product


# Component Endpoints

@app.get("/components/{component_id}", response_model=schemas.Component)
def read_component(component_id: int, db: Session = Depends(get_db)):
    db_component = crud.get_component(db, component_id=component_id)
    if db_component is None:
        raise HTTPException(status_code=404, detail="Component not found")
    return db_component


@app.post("/components/", response_model=schemas.Component)
def create_component(component: schemas.ComponentCreate, db: Session = Depends(get_db)):
    return crud.create_component(db=db, component=component)


# Add update and delete endpoints for Component


# Computer Endpoints

@app.get("/computers/{computer_id}", response_model=schemas.Computer)
def read_computer(computer_id: int, db: Session = Depends(get_db)):
    db_computer = crud.get_computer(db, computer_id=computer_id)
    if db_computer is None:
        raise HTTPException(status_code=404, detail="Computer not found")
    return db_computer


@app.post("/computers/", response_model=schemas.Computer)
def create_computer(computer: schemas.ComputerCreate, db: Session = Depends(get_db)):
    return crud.create_computer(db=db, computer=computer)


# Add update and delete endpoints for Computer


# Laptop Endpoints

@app.get("/laptops/{laptop_id}", response_model=schemas.Laptop)
def read_laptop(laptop_id: int, db: Session = Depends(get_db)):
    db_laptop = crud.get_laptop(db, laptop_id=laptop_id)
    if db_laptop is None:
        raise HTTPException(status_code=404, detail="Laptop not found")
    return db_laptop


@app.post("/laptops/", response_model=schemas.Laptop)
def create_laptop(laptop: schemas.LaptopCreate, db: Session = Depends(get_db)):
    return crud.create_laptop(db=db, laptop=laptop)


# Add update and delete endpoints for Laptop


# Cart Item Endpoints

@app.get("/cart_items/{cart_item_id}", response_model=schemas.CartItem)
def read_cart_item(cart_item_id: int, db: Session = Depends(get_db)):
    db_cart_item = crud.get_cart_item(db, cart_item_id=cart_item_id)
    if db_cart_item is None:
        raise HTTPException(status_code=404, detail="Cart Item not found")
    return db_cart_item


@app.post("/cart_items/", response_model=schemas.CartItem)
def create_cart_item(cart_item: schemas.CartItemCreate, db: Session = Depends(get_db)):
    return crud.create_cart_item(db=db, cart_item=cart_item)


# Add update and delete endpoints for Cart Item




if __name__ == "__main__":
    models.Base.metadata.create_all(bind=engine)
    
    uvicorn.run(app, host='0.0.0.0', port=8000)
